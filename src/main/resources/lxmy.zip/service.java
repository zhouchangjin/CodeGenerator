package com.newideal.booksharing.#{module}.service;

import java.util.Map;

import com.newideal.booksharing.dto.base.response.EasyUiPage;
import com.newideal.booksharing.#{module}.model.#{model};

public interface #{model}Service {
	
	public String addOrSave#{model}(#{model} entity);
	
	public #{model} get#{model}ById(String id);
	
	public boolean delete#{model}(String id);
	
	public EasyUiPage listEasyUiPage(Map<String,Object> queryObject);
	
	
	public #{model} selectById(String id);
}
