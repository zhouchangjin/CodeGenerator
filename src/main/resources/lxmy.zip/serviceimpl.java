package com.newideal.booksharing.#{module}.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.newideal.booksharing.#{module}.dao.#{model}Mapper;
import com.newideal.booksharing.#{module}.model.#{model};
import com.newideal.booksharing.dto.base.response.EasyUiPage;
import com.newideal.booksharing.util.IntegerUtil;
import com.newideal.booksharing.util.StringUtil;
import com.newideal.booksharing.util.UUIDUtils;

/**
 * {@code #{model}Impl}��
 * @author Changjin
 * @since
 * @see
 * @implNote
 */
@Service
public class #{model}ServiceImpl implements #{model}Service {
	
	@Autowired
	#{model}Mapper #{entity}Mapper;

	@Override
	public String addOrSave#{model}(#{model} entity) {
		
		if(StringUtil.isNullOrEmpty(entity.getId())) {
			String id=UUIDUtils.commonUUID();
			entity.setId(id);
			#{entity}Mapper.insertSelective(entity);
			return id;
		}else {
			#{model} exist=this.get#{model}ById(entity.getId());
			if(exist!=null) {
				#{entity}Mapper.updateByPrimaryKeySelective(entity);
				return exist.getId();
			}else {
				return "";
			}
			
		}
	}

	@Override
	public #{model} get#{model}ById(String id) {
		return #{entity}Mapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean delete#{model}(String id) {
		
		#{entity}Mapper.deleteByPrimaryKey(id);
		return true;
	}

	@Override
	public EasyUiPage listEasyUiPage(Map<String, Object> queryObject) {
		String pageStr=queryObject.get("page")==null?"1":queryObject.get("page").toString();
		String rowsStr=queryObject.get("rows")==null?"10":queryObject.get("rows").toString();
		int page=1;
		int rows=10;
		if(IntegerUtil.isPosInt(pageStr)) {
			page=Integer.parseInt(pageStr);
		}
		if(IntegerUtil.isPosInt(rowsStr)) {
			rows=Integer.parseInt(rowsStr);
		}
		PageHelper.startPage(page, rows, true); 
		List<#{model}> resultList=#{entity}Mapper.listPage(queryObject);
		PageInfo<#{model}> result = new PageInfo<#{model}>(resultList);
		EasyUiPage easypage=new EasyUiPage();
		easypage.setList(result.getList());
		easypage.setTotal(result.getTotal());
		return easypage;
	}

	@Override
	public #{model} selectById(String id) {
		return #{entity}Mapper.selectByPrimaryKey(id);
	}


}