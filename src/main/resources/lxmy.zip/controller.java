package com.newideal.booksharing.#{module}.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.newideal.booksharing.config.ServiceConfig;
import com.newideal.booksharing.dictionary.model.Dictionary;
import com.newideal.booksharing.dictionary.model.DictionaryItem;
import com.newideal.booksharing.dictionary.service.DictionaryService;
import com.newideal.booksharing.dto.base.response.EasyUiPage;
import com.newideal.booksharing.dto.base.response.Message;
import com.newideal.booksharing.dto.base.response.MetaData;
import com.newideal.booksharing.dto.base.response.MetaDataItem;
import com.newideal.booksharing.#{module}.model.#{model};
import com.newideal.booksharing.#{module}.service.#{model}Service;

@Controller
@RequestMapping("web/#{module}")
public class EasyUi#{model}Controller {
	
	
	@Autowired
	ServiceConfig config;
	
	@Autowired
	#{model}Service #{entity}Service;
	
	
	@Autowired
	DictionaryService dictionaryService;
	
	@RequestMapping(value="list", method = RequestMethod.POST)
	public @ResponseBody EasyUiPage list(@RequestParam Map<String,Object> map) {
		return #{entity}Service.listEasyUiPage(map);
	}
	
	@RequestMapping(value="meta", method = RequestMethod.POST)
	public @ResponseBody Map<String,MetaDataItem> meta(){
		MetaData<#{model}> meta=new MetaData<#{model}>(#{model}.class);
		meta.build();
		return  meta.get();
	}
	
	
	@RequestMapping(value="dictionary/{type}",method=RequestMethod.POST)
	public @ResponseBody List<DictionaryItem> dictionary(@PathVariable(value="type") String type) {
		Dictionary dictionary=dictionaryService.selectByDictionaryName(type);
		return dictionary.getDictionaryItems();
	}
	
	@RequestMapping(value="detail/{id}")
	public @ResponseBody #{model} detail(@PathVariable(value="id") String id) {
		
		return #{entity}Service.selectById(id);
		
	}
	
	@RequestMapping(value="del/{id}")
	public @ResponseBody Message del(@PathVariable(value="id") String id) {
		
		Message message=new Message();
		message.setCode("100");
		message.setMessage("成功");
		#{entity}Service.delete#{model}(id);
		return message;
	}
	
	
	@RequestMapping(value="save",method=RequestMethod.POST)
	public @ResponseBody Message save(@ModelAttribute #{model} adv) {
		Message message=new Message();
		message.setCode("100");
		message.setMessage("成功");
		String id=#{entity}Service.addOrSave#{model}(adv);
		adv.setId(id);
		message.setData(adv);
		return message;
	}

}
